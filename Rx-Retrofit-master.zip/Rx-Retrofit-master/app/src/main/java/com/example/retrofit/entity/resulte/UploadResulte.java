package com.example.retrofit.entity.resulte;

/**
 * 上传回调结果
 * Created by WZG on 2016/10/20.
 */

public class UploadResulte {

    /**
     * headImgUrl : http://www.izaodao.com/uc/data/avatar/004/81/14/20_avatar_middle.jpg?timestamp=1476943817
     */

    private String headImgUrl;

    public String getHeadImgUrl() {
        return headImgUrl;
    }

    public void setHeadImgUrl(String headImgUrl) {
        this.headImgUrl = headImgUrl;
    }
}
